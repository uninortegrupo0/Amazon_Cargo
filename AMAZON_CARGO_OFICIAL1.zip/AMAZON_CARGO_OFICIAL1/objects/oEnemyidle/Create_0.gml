/// CREATE EVENT

spd = 1.9;

// cria path
caminho = path_add();

// tamanho da célula
cell = 32;

// cria grid
grid = mp_grid_create(
    0, 0,
    room_width div cell,
    room_height div cell,
    cell, cell
);

// adiciona obstáculos
mp_grid_add_instances(grid, Oparede, false);

// controle de atualização do caminho
repath_time = 0;

// posição anterior (para detectar direção)
oldx = x;
oldy = y;

// sprite inicial
sprite_index = sEnemyidle;
image_speed = 0.2;