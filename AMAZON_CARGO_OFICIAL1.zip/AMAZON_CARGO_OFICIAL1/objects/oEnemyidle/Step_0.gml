/// STEP EVENT

//----------------------------------
// ATUALIZA CAMINHO
//----------------------------------
repath_time--;

if (repath_time <= 0 && instance_exists(Obarco))
{
    repath_time = 15;

    mp_grid_clear_all(grid);
    mp_grid_add_instances(grid, Oparede, false);

    if (mp_grid_path(grid, caminho, x, y, Obarco.x, Obarco.y, true))
    {
        path_start(caminho, spd, path_action_continue, true);
    }
}


//----------------------------------
// DIREÇÃO REAL DO MOVIMENTO
//----------------------------------
var dx = x - oldx;
var dy = y - oldy;

if (abs(dx) > 0.1 || abs(dy) > 0.1)
{
    if (abs(dx) > abs(dy))
    {
        if (dx > 0)
            sprite_index = sEnemywalkright;
        else
            sprite_index = sEnemywalkleft;
    }
    else
    {
        if (dy > 0)
            sprite_index = sEnemywalkdown;
        else
            sprite_index = sEnemywalkup;
    }

    image_speed = 0.2;
}
else
{
    image_speed = 0;
}

oldx = x;
oldy = y;