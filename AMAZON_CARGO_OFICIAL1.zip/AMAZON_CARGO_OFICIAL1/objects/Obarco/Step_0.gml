var mx = 0;
var my = 0;

// leitura das teclas
if keyboard_check(ord("D")) mx += 1;
if keyboard_check(ord("A")) mx -= 1;
if keyboard_check(ord("S")) my += 1;
if keyboard_check(ord("W")) my -= 1;

// só move se tiver input
if (mx != 0 || my != 0)
{
    // normaliza diagonal
    var len = point_distance(0, 0, mx, my);
    mx /= len;
    my /= len;

    // velocidade atual
    vel = vel_move;

    // movimento
    x += mx * vel;
    y += my * vel;

    // ângulo alvo
    var alvo = angulo;

    if (mx > 0 && my == 0)       alvo = 0;
    else if (mx > 0 && my < 0)   alvo = 45;
    else if (mx == 0 && my < 0)  alvo = 90;
    else if (mx < 0 && my < 0)   alvo = 135;
    else if (mx < 0 && my == 0)  alvo = 180;
    else if (mx < 0 && my > 0)   alvo = 225;
    else if (mx == 0 && my > 0)  alvo = 270;
    else if (mx > 0 && my > 0)   alvo = 315;

    // rotação suave
    var dif = angle_difference(alvo, angulo);

    if (abs(dif) <= giro)
    {
        angulo = alvo;
    }
    else
    {
        angulo += sign(dif) * giro;
    }

    if (angulo < 0) angulo += 360;
    if (angulo >= 360) angulo -= 360;
}
else
{
    vel = 0;
}

// escolhe uma das 16 sprites pelo ângulo
var dir16 = floor(((angulo + 11.25) mod 360) / 22.5);
sprite_index = sprites_barco[dir16];

// se suas sprites forem estáticas, isso é opcional
image_index = 0;
image_speed = 0;