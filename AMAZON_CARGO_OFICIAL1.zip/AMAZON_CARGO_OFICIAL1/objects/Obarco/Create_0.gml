vel = 0;
vel_move = 1.5;
angulo = 90;
giro = 8;

image_xscale = 1;
image_yscale = 1;

colidindo = false;

if !variable_global_exists("caixas_destruidas")
{
    global.caixas_destruidas = 0;
}

sprites_barco = [
    Sbarco_90,
    Sbarco_22,
    Sbarco_45,
    Sbarco_67,
    Sbarco_0,
    Sbarco_112,
    Sbarco_135,
    Sbarco_157,
    Sbarco_180,
    Sbarco_202,
    Sbarco_225,
    Sbarco_247,
    Sbarco_270,
    Sbarco_292,
    Sbarco_315,
    Sbarco_337
];

sprite_index = Sbarco_0;
image_speed = 0;