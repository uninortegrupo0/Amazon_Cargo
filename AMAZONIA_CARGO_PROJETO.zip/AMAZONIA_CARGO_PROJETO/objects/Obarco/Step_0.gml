if vel != 0
{
    if keyboard_check(ord("D")) { angulo -= giro }
    if keyboard_check(ord("A")) { angulo += giro }
}
if keyboard_check(ord("W"))
{
    vel += aceleracao
    if vel > vel_max { vel = vel_max }
}
else if keyboard_check(ord("S"))
{
    vel -= aceleracao
    if vel < -vel_max_re { vel = -vel_max_re }
}
if !keyboard_check(ord("W")) && !keyboard_check(ord("S"))
{
    if vel > friccao       { vel -= friccao }
    else if vel < -friccao { vel += friccao }
    else                   { vel = 0 }
}
else if keyboard_check(ord("W")) && vel < 0 { vel += friccao_op }
else if keyboard_check(ord("S")) && vel > 0 { vel -= friccao_op }


var _dx = lengthdir_x(vel, angulo)
var _dy = lengthdir_y(vel, angulo)

if !place_meeting(x + _dx, y, Osolido) { x += _dx }
if !place_meeting(x, y + _dy, Osolido) { y += _dy }

// formação de cada âlngulo
var _ang = (angulo mod 360 + 360) mod 360

if _ang >= 337.5 || _ang < 22.5   { sprite_index = Sbarco_direita }
else if _ang < 67.5                { sprite_index = Sbarco_cima_dir }
else if _ang < 112.5               { sprite_index = Sbarco_cima }
else if _ang < 157.5               { sprite_index = Sbarco_cima_esq }
else if _ang < 202.5               { sprite_index = Sbarco_esq }
else if _ang < 247.5               { sprite_index = Sbarco_baixo_esq }
else if _ang < 292.5               { sprite_index = Sbarco_baixo }
else                               { sprite_index = Sbarco_baixo_dir }