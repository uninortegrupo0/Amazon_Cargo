vel        = 0
vel_max    = 1.50
vel_max_re = 0.5
aceleracao = 0.005
friccao    = 0.0015
friccao_op = 0.015

angulo     = 90
giro       = 9


